/****************************************************************************
 *
 * Copyright 2020 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

#include "px4_ros_com/OffboardControl.hpp"

static void test_star(void) {
    OffboardControl::set_way_point({100.0, 0.0, -5.0, 0});
    OffboardControl::set_way_point({40.45, 29.39, -5.0, 0});
    OffboardControl::set_way_point({30.9, 95.11, -5.0, 0});
    OffboardControl::set_way_point({-15.45, 47.55, -5.0, 0});
    OffboardControl::set_way_point({-80.9, 58.78, -5.0, 0});
    OffboardControl::set_way_point({-50.0, 0.0, -5.0, 0});
    OffboardControl::set_way_point({-80.9, -58.78, -5.0, 0});
    OffboardControl::set_way_point({-15.45, -47.55, -5.0, 0});
    OffboardControl::set_way_point({30.9, -95.11, -5.0, 0});
    OffboardControl::set_way_point({40.45, -29.39, -5.0, 0});
    OffboardControl::set_way_point({100.0, 0.0, -5.0, 0});
}

static void test_square(void) {
    OffboardControl::set_way_point({0.0, 0.0, -5.0, -3.14});

    OffboardControl::set_way_point({100.0, .0, -10.0, 0});
    OffboardControl::set_way_point({100.0, 100.0, -15.0, 0});
    OffboardControl::set_way_point({0.0, 100.0, -5.0, 0});
    OffboardControl::set_way_point({0.0, 0.0, -5.0, 0});

    OffboardControl::set_way_point({0.0, 0.0, -5.0, -3.14});

}

int main(int argc, char *argv[])
{


	std::cout << "Starting offboard control node..." << std::endl;
	setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    OffboardControl::set_way_point({0.0, 0.0, -5.0, -3.14});
    // test_star();
    test_square();
    OffboardControl::set_way_point({0.0, 0.0, -5.0, -3.14});
    OffboardControl::set_way_point({0.0, 0.0, 0.0, -3.14});

	rclcpp::init(argc, argv);
	rclcpp::spin(std::make_shared<OffboardControl>());

	rclcpp::shutdown();
	return 0;
}
