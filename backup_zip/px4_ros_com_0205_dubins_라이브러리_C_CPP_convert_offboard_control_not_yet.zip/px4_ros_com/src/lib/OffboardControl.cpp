/****************************************************************************
 *
 * Copyright 2020 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

#include "px4_ros_com/OffboardControl.hpp"
#include "px4_ros_com/Dubins.hpp"

std::queue<std::array<float, 4>> OffboardControl::way_points_;

OffboardControl::OffboardControl() : Node("offboard_control") {
		offboard_control_mode_publisher_ = this->create_publisher<OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
		trajectory_setpoint_publisher_ = this->create_publisher<TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);
		vehicle_command_publisher_ = this->create_publisher<VehicleCommand>("/fmu/in/vehicle_command", 10);

		rmw_qos_profile_t qos_profile = rmw_qos_profile_sensor_data;
		auto qos = rclcpp::QoS(rclcpp::QoSInitialization(qos_profile.history, 5), qos_profile);
		vehicle_local_position_subscription_ = this->create_subscription<px4_msgs::msg::VehicleLocalPosition>("/fmu/out/vehicle_local_position", qos, [this](const px4_msgs::msg::VehicleLocalPosition::UniquePtr msg) {
                local_position_ = {msg->x, msg->y, msg->z, msg->heading};
                const int width = 10;
                std::cout << std::fixed << std::setprecision(2); // 소수점 이하 두 자리까지만 표시
                std::cout << "\n\n"
                          << "RECEIVED SENSOR COMBINED DATA\n"
                          << "===================================================\n"
                          << "  Local Position  |  Way Point\n"
                          << "===================================================\n"
                          << "North: " << std::setw(width) << local_position_[NORTH] << " ➔ " 
                              << std::setw(width) << way_points_.front()[NORTH] << "\n"
                          << "East : " << std::setw(width) << local_position_[EAST]  << " ➔ " 
                              << std::setw(width) << way_points_.front()[EAST] << "\n"
                          << "Down : " << std::setw(width) << local_position_[DOWN]  << " ➔ " 
                              << std::setw(width) << way_points_.front()[DOWN] << "\n"
                          << "Yaw  : " << std::setw(width) << local_position_[YAW]   << " | " 
                              << std::setw(width) << way_points_.front()[YAW] << "\n"
                          << "===================================================\n"
                          << "Left way points: " << way_points_.size() << "\n"
                          << "===================================================\n";
                });

		offboard_setpoint_counter_ = 0;

		auto timer_callback = [this]() -> void {

			if (offboard_setpoint_counter_ == 10) {
				// Change to Offboard mode after 10 setpoints
				this->publish_vehicle_command(VehicleCommand::VEHICLE_CMD_DO_SET_MODE, 1, 6);

				// Arm the vehicle
				this->arm();
			}

			// offboard_control_mode needs to be paired with trajectory_setpoint
			publish_offboard_control_mode();
			publish_trajectory_setpoint();

			// stop the counter after reaching 11
			if (offboard_setpoint_counter_ < 11) {
				offboard_setpoint_counter_++;
			}
		};
		timer_ = this->create_wall_timer(100ms, timer_callback);
	}


/**
 * @brief Send a command to Arm the vehicle
 */
void OffboardControl::arm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0);

	RCLCPP_INFO(this->get_logger(), "Arm command send");
}

/**
 * @brief Send a command to Disarm the vehicle
 */
void OffboardControl::disarm()
{
	publish_vehicle_command(VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0);

	RCLCPP_INFO(this->get_logger(), "Disarm command send");
}

/**
 * @brief Publish the offboard control mode.
 *        For this example, only position and altitude controls are active.
 */
void OffboardControl::publish_offboard_control_mode()
{
	OffboardControlMode msg{};
	msg.position = true;
	msg.velocity = false;
	msg.acceleration = false;
	msg.attitude = false;
	msg.body_rate = false;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	offboard_control_mode_publisher_->publish(msg);
}

/**
 * @brief Publish a trajectory setpoint
 *        For this example, it sends a trajectory setpoint to make the
 *        vehicle hover at 5 meters with a yaw angle of 180 degrees.
 */
void OffboardControl::publish_trajectory_setpoint()
{
	TrajectorySetpoint msg{};
	msg.position = {way_points_.front()[NORTH], way_points_.front()[EAST], way_points_.front()[DOWN]};
    msg.yaw = way_points_.front()[YAW] ? way_points_.front()[YAW]
                : atan2(way_points_.front()[EAST] - local_position_[EAST], 
                        way_points_.front()[NORTH] - local_position_[NORTH]); // -pi ~ pi
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	trajectory_setpoint_publisher_->publish(msg);
    if (way_points_.size() == 1) {
        return ;
    }
    if (is_reach_way_point_with_norm()) {
        std::cout << "way point reached" << std::endl;
        way_points_.pop();
    }
}

bool OffboardControl::is_reach_way_point_with_square(void) {
    return (abs(local_position_[NORTH] - way_points_.front()[NORTH]) < 1.0 &&
        abs(local_position_[EAST] - way_points_.front()[EAST]) < 1.0 &&
        abs(local_position_[DOWN] - way_points_.front()[DOWN]) < 1.0);
}

bool OffboardControl::is_reach_way_point_with_norm(void) {
    return (sqrt(pow(local_position_[NORTH] - way_points_.front()[NORTH], 2) +
                 pow(local_position_[EAST] - way_points_.front()[EAST], 2) +
                 pow(local_position_[DOWN] - way_points_.front()[DOWN], 2)) < 1.0);
}
        // abs(local_position_[YAW] - way_points_.front()[YAW]) < 1.0) {

/**
 * @brief Publish vehicle commands
 * @param command   Command code (matches VehicleCommand and MAVLink MAV_CMD codes)
 * @param param1    Command parameter 1
 * @param param2    Command parameter 2
 */
void OffboardControl::publish_vehicle_command(uint16_t command, float param1, float param2)
{
	VehicleCommand msg{};
	msg.param1 = param1;
	msg.param2 = param2;
	msg.command = command;
	msg.target_system = 1;
	msg.target_component = 1;
	msg.source_system = 1;
	msg.source_component = 1;
	msg.from_external = true;
	msg.timestamp = this->get_clock()->now().nanoseconds() / 1000;
	vehicle_command_publisher_->publish(msg);
}

// void OffboardControl::dubins_path_planning(float x, float y) {
//
// }

void OffboardControl::set_way_point(std::array<float, 4> way_point) {
    OffboardControl::way_points_.push(way_point); 
}

