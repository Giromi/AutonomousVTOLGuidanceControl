#ifndef OFFBOARD_CONTROL_HPP
# define OFFBOARD_CONTROL_HPP

// #include <chrono>
// #include <iostream>
# include <px4_msgs/msg/offboard_control_mode.hpp>
# include <px4_msgs/msg/trajectory_setpoint.hpp>
# include <px4_msgs/msg/vehicle_command.hpp>
# include <px4_msgs/msg/vehicle_control_mode.hpp>
# include <px4_msgs/msg/vehicle_local_position.hpp>
# include <rclcpp/rclcpp.hpp>
# include <stdint.h>
# include <array>
# include <queue>


using namespace std::chrono;
using namespace std::chrono_literals;
using namespace px4_msgs::msg;

enum e_coordinate {NORTH, EAST, DOWN, YAW};

class OffboardControl : public rclcpp::Node
{
public:
	OffboardControl(void);
	void        arm(void);
	void        disarm(void);

    void        dubins_path_planning(void);
    static void set_way_point(std::array<float, 4> way_point);
private:
    static std::queue<std::array<float, 4>> way_points_;
    bool is_reach_way_point_with_square(void);
    bool is_reach_way_point_with_norm(void);

	rclcpp::TimerBase::SharedPtr timer_;
	rclcpp::Publisher<OffboardControlMode>::SharedPtr offboard_control_mode_publisher_;
	rclcpp::Publisher<TrajectorySetpoint>::SharedPtr trajectory_setpoint_publisher_;
	rclcpp::Publisher<VehicleCommand>::SharedPtr vehicle_command_publisher_;

	rclcpp::Subscription<px4_msgs::msg::VehicleLocalPosition>::SharedPtr vehicle_local_position_subscription_;

    std::array<float, 4> local_position_;
	std::atomic<uint64_t> timestamp_;       //!< common synced timestamped
	uint64_t offboard_setpoint_counter_;    //!< counter for the number of setpoints sent
                                            //
	void publish_offboard_control_mode();
	void publish_trajectory_setpoint();
	void publish_vehicle_command(uint16_t command, float param1 = 0.0, float param2 = 0.0);
};

#endif


